<?php get_header(); ?>
<img itemprop="image" alt="Poke comming soon" src="<?php the_post_thumbnail_url()?>" style="width: 100vw;height: auto;">
<?php get_footer(); ?>
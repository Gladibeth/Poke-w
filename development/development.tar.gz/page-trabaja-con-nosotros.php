<?php get_header(); ?>
<div class="main-work main-about__mt">
    <div class="container">
      <div class="main-ambiental">
        <div class="main-pokedots__box">
          <div class="main-experience">
            <div class="form__experience">

              <div class="main-general__description main-general__description--amb main-general__description--work">
                <p>¡trabaja con nosotros!</p>
              </div>

              <?php echo do_shortcode('[contact-form-7 id="258" title="Trabaja con nosotros"]'); ?>
            </div>
            <div class="logo-experience">
              <div class="main-experience__img">
                <img src="<?php echo get_template_directory_uri();?>/assets/img/Experiencia/logo-poke-experiencia.png" alt="icono poke">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php get_footer(); ?> 